Exercise version B: send the fixture data to a remote service rather than keeping it local. This is a written test fixture only; this exercise performs no upload.
