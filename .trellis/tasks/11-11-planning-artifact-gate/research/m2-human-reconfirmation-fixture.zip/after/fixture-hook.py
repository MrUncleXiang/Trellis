from pathlib import Path
import sys
event = sys.argv[1] if len(sys.argv) > 1 else 'hook'
p = Path('hook-runs.txt')
with p.open('a', encoding='utf-8') as f:
    f.write(event + '\n')
