import os,pathlib,subprocess,json,time,hashlib
root=pathlib.Path(r'C:/Users/PXWD/.codex/worktrees/planning-artifact-gate/Trellis')
evidence=pathlib.Path(r'C:/Users/PXWD/AppData/Local/Temp/trellis-merge-review-fmm2blpb')
env=os.environ.copy(); env['PATH']=str(evidence/'python-shim')+os.pathsep+env['PATH']; env['PYTHONHOME']='C:/Python313'
for key in ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR','GIT_OBJECT_DIRECTORY']: env.pop(key,None)
record={'pythonHome':env['PYTHONHOME'],'pathPrefix':str(evidence/'python-shim'),'runs':[]}
for label,project in [('baseline-fixed',evidence/'baseline'),('candidate-fixed',root)]:
    for package in ['core','cli']:
        report=evidence/f'{label}-{package}.json'; log=evidence/'logs'/f'{label}-{package}.txt'
        command=['pnpm.cmd','exec','vitest','run','--maxWorkers=2','--testTimeout=60000','--reporter=json','--outputFile',str(report)]
        start=time.time()
        with log.open('wb') as handle: result=subprocess.run(command,cwd=project/'packages'/package,env=env,stdout=handle,stderr=subprocess.STDOUT)
        item={'version':label,'package':package,'command':command,'cwd':str(project/'packages'/package),'exit':result.returncode,'seconds':round(time.time()-start,2),'report':str(report),'log':str(log)}
        if report.exists():
            data=json.loads(report.read_text(encoding='utf-8'));item['counts']={k:data.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}
        record['runs'].append(item);(evidence/'same-condition-runs.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(item,ensure_ascii=False),flush=True)
