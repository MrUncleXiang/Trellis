import pathlib,subprocess,tarfile,io,json,hashlib,time,os
root=pathlib.Path.cwd();e=pathlib.Path(r'C:/Users/PXWD/AppData/Local/Temp/trellis-merge-review-fmm2blpb');base=e/'baseline';records=[]
for project,ref,target in [(root,'f089cb3286071199e84118dee86b6d76aab032f1',base),(root/'marketplace','7d5298d16e07c328c09493eed1f0652571744b17',base/'marketplace')]:
 data=subprocess.check_output(['git','-c','core.autocrlf=false','-c','core.eol=lf','archive','--format=tar',ref],cwd=project)
 with tarfile.open(fileobj=io.BytesIO(data)) as archive:archive.extractall(target,filter='data')
 records.append({'ref':ref,'sha256':hashlib.sha256(data).hexdigest(),'command':'git -c core.autocrlf=false -c core.eol=lf archive --format=tar '+ref})
p='packages/cli/src/templates/trellis/workflow.md';q='marketplace/workflows/native/workflow.md';assert (base/p).read_bytes()==(base/q).read_bytes()
(e/'baseline-canonical-export.json').write_text(json.dumps({'archives':records,'baselineWorkflowByteParity':True,'reason':'Original archive applied Windows autocrlf filter to submodule only; canonical export prevents false drift.'},indent=2),encoding='utf-8')
env=os.environ.copy();env['PATH']=str(e/'python-shim')+os.pathsep+env['PATH'];env['PYTHONHOME']='C:/Python313'
for key in ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR','GIT_OBJECT_DIRECTORY']:env.pop(key,None)
command=['pnpm.cmd','exec','vitest','run','--maxWorkers=2','--testTimeout=60000','--reporter=json','--outputFile',str(e/'baseline-canonical-cli.json')];start=time.time()
with (e/'logs/baseline-canonical-cli.txt').open('wb') as log:result=subprocess.run(command,cwd=base/'packages/cli',env=env,stdout=log,stderr=subprocess.STDOUT)
d=json.loads((e/'baseline-canonical-cli.json').read_text(encoding='utf-8'));record={'version':'baseline-canonical','package':'cli','exit':result.returncode,'seconds':round(time.time()-start,2),'command':command,'counts':{k:d.get(k) for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}}
(e/'baseline-canonical-exit.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record),flush=True)
